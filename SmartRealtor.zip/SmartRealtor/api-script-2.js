let myValueClone;

let myValue;

let NewValue;


async function fetchTest() {
    try {
       const MyData= await fetch('https://localhost:7129/api/Values/GetPWDVerificationStatus?PWD=MyAWS123', {
      method: 'GET',
    });
     const text = await MyData.text();
if( text == "YES")
{
    document.getElementById("content").innerHTML='<object data="A.html" width="500" height="200"></object>';
    console.log(text);
}

      console.log( MyData);
} catch (error) {
    console.error(error);
  }
}

(async() => {
    await fetchTest();
  
   

})();

 