let myValueClone;

let myValue;

let NewValue;


async function fetchTest() {
    try {
       const MyData= await fetch('https://localhost:7129/api/Values/GetMyData?PWD=MyAWS123', {
      method: 'GET',
    });

    

     const text = await MyData.text();
document.getElementById("content").innerHTML= text ;


} catch (error) {
    console.error(error);
  }
}

(async() => {
    await fetchTest();
  
   

})();

 