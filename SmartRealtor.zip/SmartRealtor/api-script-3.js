let myValueClone;

let myValue;

function currentloginid() {
  return fetch('https://localhost:7129/api/Values?id=12&PWD=MyAWS123', {
      method: 'GET',
    })
    .then(function(response) {
       
       return response;
    })
    .then(function(data) {
      var userid = data.clone();
      myValue = data.clone();
      myValueClone = data.clone();
      console.log(myValue);
      console.log(userid);
      return userid;
    })
}

currentloginid();
console.log(myValueClone);