const params = {
    
   
};
const options = {
    method: 'GET',
    body: JSON.stringify( params )  
};
var res = fetch( 'https://localhost:7129/api/Values?id=12&PWD=MyAWS123' , {
      method: 'GET',
    })
    .then(function(jsonData) {
        console.log(JSON.stringify( jsonData));
	return jsonData;
})
.then(function(MyData) {
	console.log(JSON.stringify( MyData.PromiseResult.text()));
        
        if(  MyData.value2 == "YES")
{
  console.log( "Ïnside Matched");
  document.getElementById("content").innerHTML='<object data="A.html" width="500" height="200"></object>';
}

        return MyData;
});
console.log("Printing Output");
console.log(res);

