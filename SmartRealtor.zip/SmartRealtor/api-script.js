var Mydata = fetch('https://localhost:7129/api/Values?id=12?PWD=Abc!@#VCDzx',{
  method: 'GET',
  headers: {
    Accept: 'application.json',
    'Content-Type': 'application/json'
  }
  })
.then(function(response) {
	return response.json();
})
.then(function(jsonData) {
	console.log(jsonData)
	return jsonData;
})
.then(function(Data) {
	console.log(Data);
	return Data;
});
console.log("Printing Output");
console.log("Here we go Data" + Mydata);
if( Mydata == 1)
{
  document.getElementById("content").innerHTML='<object data="A.html" width="500" height="200"></object>';
}
